package com.example.casestudy

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.layout_url.view.*

class UrlAdapter(val urls : List<Url>) : RecyclerView.Adapter<UrlAdapter.UrlViewHolder>() {


    class UrlViewHolder(val view: View) : RecyclerView.ViewHolder(view)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UrlViewHolder {
        return UrlViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.layout_url, parent, false)
        )


    }

    override fun getItemCount(): Int {

        return urls.size
    }

    override fun onBindViewHolder(holder: UrlViewHolder, position: Int) {
        val url = urls[position]
        holder.view.textViewTitle.text = url.login
        holder.view.textViewDescription.text = url.description
        Glide.with(holder.view.context)
            .load(url.avatar_url)
            .into(holder.view.imageView)

        holder.itemView.setOnClickListener {
            var activity = holder.itemView.context as Activity
            var intent = Intent(activity, ResultActivity::class.java)
            intent.putExtra("iTitle", urls[position].login)
            intent.putExtra("my_id", urls[position].id)
            intent.putExtra("my_node_id", urls[position].node_id)
            intent.putExtra("my_url", urls[position].url)
            intent.putExtra("my_repos_url", urls[position].repos_url)
            intent.putExtra("my_events_url", urls[position].events_url)
            intent.putExtra("my_hooks_url", urls[position].hooks_url)
            intent.putExtra("my_issues_url", urls[position].issues_url)
            intent.putExtra("my_members_url",urls[position].members_url)
            intent.putExtra("my_public_members_url", urls[position].public_members_url)
            intent.putExtra("image_url",urls[position].avatar_url)
            intent.putExtra("my_description",urls[position].description)
            activity?.startActivity(intent)


        }
    }
}







