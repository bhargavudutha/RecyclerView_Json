package com.example.casestudy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.layout_url.view.*

class ResultActivity : AppCompatActivity() {
    lateinit var result:TextView
    lateinit var result2:TextView
    lateinit var my_image:ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        result=findViewById(R.id.textView)
        result2=findViewById(R.id.textView2)
        my_image=findViewById(R.id.imageView3)

        /*val actionBar: ActionBar?=supportActionBar
        actionBar!!.setDisplayHomeAsUpEnabled(true)
        actionBar!!.setDisplayHomeAsUpEnabled(true)
        actionBar.setTitle(aTitle)
        result.text=aTitle
        //result2.text=aDescription*/
        var aTitle:String=intent.getStringExtra("iTitle").toString()
        var aid:Int=intent.getIntExtra("my_id",0)
        var anodeid:String=intent.getStringExtra("my_node_id").toString()
        var aurl:String=intent.getStringExtra("my_url").toString()
        var areposurl:String=intent.getStringExtra("my_repos_url").toString()
        var aeventsurl:String=intent.getStringExtra("my_events_url").toString()
        var ahooksurl:String=intent.getStringExtra("my_hooks_url").toString()
        var aissuesurl:String=intent.getStringExtra("my_issues_url").toString()
        var amembersurl:String=intent.getStringExtra("my_members_url").toString()
        var apublicmembersurl:String=intent.getStringExtra("my_public_members_url").toString()
        // var aimageurl:String=intent.getStringExtra("image_url").toString()
        var adescription:String=intent.getStringExtra("my_description").toString()

        Glide.with(this@ResultActivity).load(intent.getStringExtra("image_url")).into(my_image)



        result.text="$aTitle"
        result2.text="$aid\n$anodeid\n$aurl\n$areposurl\n$aeventsurl\n$ahooksurl\n$aissuesurl\n$amembersurl\n$apublicmembersurl\n$adescription"
    }
}

