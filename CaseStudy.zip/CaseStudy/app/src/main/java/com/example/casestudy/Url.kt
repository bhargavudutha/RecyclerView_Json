package com.example.casestudy

data class Url(
    val login:String?=null,
    val id: Int?=0,
    val node_id:String?=null,
    val url:String?=null,
    val repos_url:String?=null,
    val events_url:String?=null,
    val hooks_url:String?=null,
    val issues_url:String?=null,
    val members_url:String?=null,
    val public_members_url:String?=null,
    val avatar_url: String?=null,
    val description:String?=null
)
