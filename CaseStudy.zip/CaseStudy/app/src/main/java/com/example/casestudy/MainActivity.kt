package com.example.casestudy

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fetchUrls()

    }

    private fun fetchUrls(){

        UrlApi().getUrls().enqueue(object : Callback<List<Url>> {
            override fun onFailure(call: Call<List<Url>>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<List<Url>>, response: Response<List<Url>>) {

                val urls = response.body()

                urls?.let {
                    showUrls(it)
                }
            }

        })
    }

    private fun showUrls(urls: List<Url>) {
        recyclerViewUrls.layoutManager = LinearLayoutManager(this)
        recyclerViewUrls.adapter = UrlAdapter(urls)

    }
}
